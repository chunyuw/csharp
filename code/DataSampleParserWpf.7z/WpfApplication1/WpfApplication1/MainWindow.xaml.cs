﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Text.RegularExpressions;
using System.IO;

namespace WpfApplication1
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public SampleParser p;
        public MainWindow()
        {
            InitializeComponent();
            p = new SampleParser("Sample.csv");

            label1.Content = p.Header;

            textBox1.Text = p.DataSetName;


            dataGrid1.DataContext = p;
            dataGrid1.ItemsSource = p.InputsTable;
            DataGridTextColumn c;
            string[] InputHeader = new string[] { "Name", "Value", "Unit" };
            for (int i = 0; i < 3; i++)
            {
                c = new DataGridTextColumn();
                c.Header = InputHeader[i];
                c.Binding = new Binding(string.Format("[{0}]", i));

                dataGrid1.Columns.Add(c);
            }

            dataGrid2.DataContext = p;
            dataGrid2.ItemsSource = p.DataTable;
            for (int i = 0; i < p.DataColumnName.Length; i++)
            {
                c = new DataGridTextColumn();
                c.Header = p.DataColumnName[i];
                c.Binding = new Binding(string.Format("[{0}]", i));

                dataGrid2.Columns.Add(c);
            }

        }


    }

    public class SampleParser
    {
        public string Header;            // Header 

        public string DataSetName;       // Data Set Name

        public int InputsCount;          // the number of total inputs
        public string[] InputsName;      // Column 1
        public string[] InputsValue;     // Column 2
        public string[] InputsUnit;      // Column 3
        public List<string[]> InputsTable;

        public int DataColumnCount;      // the number of total columns in data table
        public string[] DataColumnName;  // the name of each column
        public string[] DataColumnUnit;  // the unit of each column, if enclosed in brackets, or empty string("")
        public List<string[]> DataTable;  // the data table
        

        public SampleParser(string inputfilename)
        {
            string[] csvLines = File.ReadAllLines(inputfilename).Select(line => line.Trim()).ToArray<string>();

            var emptylines = Enumerable.Range(0, csvLines.Length).Where(i => Regex.IsMatch(csvLines[i], @"^[,\s]*$"));
            var sepLines = emptylines.Where(i => !(emptylines.Contains(i - 1))).ToArray<int>();

            var header = csvLines.Skip(0).Take(sepLines[0]).Where(line => !(Regex.IsMatch(line, @"^[,\s]*$")));
            var datset = csvLines.Skip(sepLines[0]).Take(sepLines[1] - sepLines[0]).Where(line => !(Regex.IsMatch(line, @"^[,\s]*$")));
            var inputs = csvLines.Skip(sepLines[1]).Take(sepLines[2] - sepLines[1]).Where(line => !(Regex.IsMatch(line, @"^[,\s]*$"))).Select(line => csvsplit(line));
            var tables = csvLines.Skip(sepLines[2]).Take(csvLines.Length - sepLines[2]).Where(line => !(Regex.IsMatch(line, @"^[,\s]*$")));
            var data = tables.Skip(1);

            Header = string.Join("\n", header.Select(w => w.TrimEnd(new char[] { ',' })));

            DataSetName = string.Join("", datset.Select(w => w.Trim(new char[] { ',', '[', ']' })));

            InputsCount = inputs.Count();
            InputsName = inputs.Select(w => w[0]).ToArray<string>();
            InputsValue = inputs.Select(w => w[1]).ToArray<string>();
            InputsUnit = inputs.Select(w => w[2]).ToArray<string>();
            InputsTable = inputs.ToList<string[]>();

            var tmp2 = tables.Take(1).ToArray<string>()[0].Split(new char[] { ',' });
            DataColumnUnit = tmp2.Select(w => Regex.Match(w, @"\[(?<u>.*?)\]").Groups["u"].Value).ToArray<string>();
            DataColumnName = Enumerable.Range(0, tmp2.Length).Select(i => tmp2[i].Replace("[" + DataColumnUnit[i] + "]", "")).ToArray<string>();
            DataColumnCount = DataColumnName.Length;

            DataTable = data.Select(w => csvsplit(w)).ToList<string[]>();
            //DataColumns = Enumerable.Range(0, DataColumnCount).Select(i => tmp3.Select(w => w[i]).ToArray<string>()).ToList<string[]>();

        }

        Regex re = new Regex("(?<q>\".*?\")");
        public string[] csvsplit(string line)
        {
            line = line.Replace("QUOTED", "QQUUOOTTEEDD");
            foreach (Match m in re.Matches(line))
                line = line.Replace(m.Value, m.Value.Replace(",", "QUOTED"));
            return line.Split(new char[] { ',' }).Select(w => w.Replace("QUOTED", ",").Replace("QQUUOOTTEEDD", "QUOTED")).ToArray<string>();
        }


    }
}
