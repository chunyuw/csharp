using System;

public class test
{ 
  public static void Main()
  { 
    int x = 1;

    for (int i=0; i<64; i++)
    { 
      x = x * 2;
      Console.WriteLine ( x );
    }
  }
}

