using System;

public class test
{
  public static void Main()
  {
    char a;
    
    for(int i=19970; i< 40000; i++)
    {
      a = (char)i;
      Console.Write (a);
      if ((i%30)==0) Console.WriteLine();
    }
  }
}

