using System;

public class test
{
  public static void Main()
  {

    int a[10];
    
    for (int i=0; i<10; i++)
    {
      a[i] = i*i;
    }

    int sum;
    foreach (x in a)
    {
      sum += x;
    }
    Console.WriteLine ("sum = {0}", sum);

  }
}

