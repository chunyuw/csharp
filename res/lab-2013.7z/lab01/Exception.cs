using System;

public class test
{
  public static void Main()
  {
    int i = 1000000;
    int j;

    j = checked(i * i);  // ʹ��try{ ... }��ֹ�����˳�
    Console.WriteLine(j);


    Console.WriteLine("Program Finished.");
  }
}

